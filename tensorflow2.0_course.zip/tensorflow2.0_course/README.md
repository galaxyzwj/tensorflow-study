# tensorflow2.0_course

Tensorflow2.0课程代码库

## 部分课程数据

下载链接: https://pan.baidu.com/s/12eCFng1QlgsroZ99YtLpRQ  密码:dapq

目前已有数据：

- 中文文本数据
- tensorflow_datasets : 使用tfds时下载的数据，可以将文件夹下载下来放在home目录下即可在tfds中用

